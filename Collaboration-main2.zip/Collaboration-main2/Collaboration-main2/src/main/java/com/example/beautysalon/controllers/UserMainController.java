package com.example.beautysalon.controllers;

import com.example.beautysalon.MainApp;
import com.example.beautysalon.models.Product;
import com.example.beautysalon.models.Service;
import com.example.beautysalon.services.CartService;
import com.example.beautysalon.services.CatalogService;
import com.example.beautysalon.services.UserService;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.geometry.Pos;
import javafx.geometry.Insets;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

public class UserMainController {
    @FXML private VBox mainContainer;
    @FXML private Button cartButton;
    @FXML private Label cartCountLabel;
    @FXML private HBox topBar; // Добавим ссылку на верхнюю панель

    private CatalogService catalogService = new CatalogService();
    private CartService cartService = new CartService();
    private final UserService userService = UserService.getInstance();

    // Карта соответствия названий товаров и услуг путям к изображениям
    private final Map<String, String> serviceImageMap = new HashMap<>();
    private final Map<String, String> productImageMap = new HashMap<>();

    @FXML
    public void initialize() {
        initializeImageMappings();
        updateCartCount();
        showMainMenu();

        // Стилизуем кнопку корзины
        if (cartButton != null) {
            cartButton.setStyle(
                    "-fx-background-color: #8B008B; " +
                            "-fx-text-fill: white; " +
                            "-fx-font-weight: bold; " +
                            "-fx-background-radius: 20; " +
                            "-fx-border-radius: 20; " +
                            "-fx-padding: 8 20; " +
                            "-fx-font-size: 14px;"
            );
        }
    }

    private void initializeImageMappings() {
        serviceImageMap.put("Маникюр гель-лак", "/images/manicure.jpg");
        serviceImageMap.put("Стрижка женская", "/images/haircut.jpg");
        serviceImageMap.put("Прокол ушей", "/images/piercing.jpg");
        serviceImageMap.put("Педикюр", "/images/pedicure.jpg");
        serviceImageMap.put("Окрашивание волос", "/images/haircolor.jpg");
        serviceImageMap.put("Прокол носа", "/images/nosepiercing.jpg");
        serviceImageMap.put("Наращивание ресниц", "/images/resnichka.jpg");
        serviceImageMap.put("Макияж", "/images/makeup.jpg");
        serviceImageMap.put("СПА-массаж", "/images/SPA.jpg");

        productImageMap.put("Крем для лица", "/images/facecream.jpg");
        productImageMap.put("Лосьон для тела", "/images/bodylotion.jpg");
        productImageMap.put("Сыворотка", "/images/serum.jpg");
        productImageMap.put("Масло для тела", "/images/bodyoil.jpg");
        productImageMap.put("Тоник для лица", "/images/toner.jpg");
        productImageMap.put("Скраб для тела", "/images/scrub.jpg");
        productImageMap.put("Шампунь для волос", "/images/CHAMPYX.jpg");
        productImageMap.put("Бальзам для губ", "/images/lips.jpg");
        productImageMap.put("Гель для душа", "/images/Gel.jpg");
        productImageMap.put("Гель-лак", "/images/nails.jpg");
    }

    private void showMainMenu() {
        mainContainer.getChildren().clear();

        VBox welcomeBox = new VBox(15);
        welcomeBox.setAlignment(Pos.CENTER);
        welcomeBox.setPadding(new Insets(30, 0, 40, 0));

        ImageView logoImage = loadImage("/images/logo.png", "/images/salon_icon.png", "/images/default.jpg");
        if (logoImage != null) {
            logoImage.setFitWidth(120);
            logoImage.setFitHeight(120);
            welcomeBox.getChildren().add(logoImage);
        }

        Label welcomeText = new Label("Добро пожаловать в Studio Mariana");
        welcomeText.setStyle("-fx-font-size: 28px; -fx-font-weight: bold; -fx-text-fill: #8B008B;");

        Label subtitle = new Label("Выберите категорию");
        subtitle.setStyle("-fx-font-size: 16px; -fx-text-fill: #666;");

        welcomeBox.getChildren().addAll(welcomeText, subtitle);
        mainContainer.getChildren().add(welcomeBox);

        FlowPane categoriesPane = new FlowPane();
        categoriesPane.setAlignment(Pos.CENTER);
        categoriesPane.setHgap(30);
        categoriesPane.setVgap(30);
        categoriesPane.setPadding(new Insets(20));

        VBox servicesCard = createCategoryCard(
                "Услуги",
                "💅",
                "Маникюр, стрижки, окрашивание и другие услуги",
                "#8B008B"
        );

        VBox productsCard = createCategoryCard(
                "Товары",
                "🛍️",
                "Косметика для ухода за лицом и телом",
                "#FF69B4"
        );

        categoriesPane.getChildren().addAll(servicesCard, productsCard);
        mainContainer.getChildren().add(categoriesPane);
    }

    private VBox createCategoryCard(String title, String emoji, String description, String color) {
        VBox card = new VBox(15);
        card.setAlignment(Pos.CENTER);
        card.setPrefSize(280, 260);
        card.setStyle(
                "-fx-background-color: white; " +
                        "-fx-border-color: " + color + "; " +
                        "-fx-border-width: 2; " +
                        "-fx-border-radius: 15; " +
                        "-fx-background-radius: 15; " +
                        "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.1), 10, 0.5, 0, 2);"
        );
        card.setPadding(new Insets(25));

        Label emojiLabel = new Label(emoji);
        emojiLabel.setStyle("-fx-font-size: 48px; -fx-padding: 0 0 10 0;");

        Label titleLabel = new Label(title);
        titleLabel.setStyle("-fx-font-size: 22px; -fx-font-weight: bold; -fx-text-fill: " + color + ";");

        Label descLabel = new Label(description);
        descLabel.setStyle("-fx-font-size: 13px; -fx-text-fill: #666; -fx-text-alignment: center;");
        descLabel.setWrapText(true);
        descLabel.setMaxWidth(230);

        Button selectButton = new Button("Перейти →");
        selectButton.setStyle(
                "-fx-background-color: " + color + "; " +
                        "-fx-text-fill: white; " +
                        "-fx-font-size: 14px; " +
                        "-fx-padding: 8 20; " +
                        "-fx-background-radius: 20; " +
                        "-fx-border-radius: 20;"
        );
        selectButton.setOnAction(e -> {
            if (title.equals("Услуги")) showServicesCatalog();
            else showProductsCatalog();
        });

        card.getChildren().addAll(emojiLabel, titleLabel, descLabel, selectButton);

        card.setOnMouseEntered(e -> {
            card.setStyle(
                    "-fx-background-color: #F9F9F9; " +
                            "-fx-border-color: " + color + "; " +
                            "-fx-border-width: 3; " +
                            "-fx-border-radius: 15; " +
                            "-fx-background-radius: 15; " +
                            "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.15), 15, 0.5, 0, 3);"
            );
        });

        card.setOnMouseExited(e -> {
            card.setStyle(
                    "-fx-background-color: white; " +
                            "-fx-border-color: " + color + "; " +
                            "-fx-border-width: 2; " +
                            "-fx-border-radius: 15; " +
                            "-fx-background-radius: 15; " +
                            "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.1), 10, 0.5, 0, 2);"
            );
        });

        return card;
    }

    private void showServicesCatalog() {
        mainContainer.getChildren().clear();

        HBox headerBox = new HBox(15);
        headerBox.setAlignment(Pos.CENTER_LEFT);
        headerBox.setPadding(new Insets(20, 20, 30, 20));

        // Кнопка "Назад" для услуг - фиолетовая
        Button backButton = new Button("← Назад");
        backButton.setStyle(
                "-fx-background-color: #8B008B; " +
                        "-fx-text-fill: white; " +
                        "-fx-font-size: 14px; " +
                        "-fx-padding: 8 20; " +
                        "-fx-background-radius: 20; " +
                        "-fx-border-radius: 20; " +
                        "-fx-font-weight: bold;"
        );
        backButton.setOnAction(e -> showMainMenu());

        Label title = new Label("Услуги салона");
        title.setStyle("-fx-font-size: 28px; -fx-font-weight: bold; -fx-text-fill: #8B008B;");

        HBox.setHgrow(title, Priority.ALWAYS);
        title.setAlignment(Pos.CENTER);

        headerBox.getChildren().addAll(backButton, title);
        mainContainer.getChildren().add(headerBox);

        HBox filterBox = new HBox(10);
        filterBox.setAlignment(Pos.CENTER);
        filterBox.setPadding(new Insets(0, 0, 20, 0));

        ToggleGroup categoryGroup = new ToggleGroup();

        ToggleButton allButton = createFilterButton("Все", categoryGroup, "#8B008B");
        ToggleButton manicureButton = createFilterButton("Маникюр", categoryGroup, "#8B008B");
        ToggleButton haircutButton = createFilterButton("Стрижка", categoryGroup, "#8B008B");
        ToggleButton piercingButton = createFilterButton("Проколы", categoryGroup, "#8B008B");
        ToggleButton coloringButton = createFilterButton("Окрашивание", categoryGroup, "#8B008B");
        ToggleButton massageButton = createFilterButton("Массаж", categoryGroup, "#8B008B");

        allButton.setSelected(true);

        categoryGroup.selectedToggleProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal == allButton) displayServices(null);
            else if (newVal == manicureButton) displayServices("Маникюр");
            else if (newVal == haircutButton) displayServices("Стрижка");
            else if (newVal == piercingButton) displayServices("Проколы");
            else if (newVal == coloringButton) displayServices("Окрашивание");
            else if (newVal == massageButton) displayServices("Массаж");
        });

        filterBox.getChildren().addAll(allButton, manicureButton, haircutButton,
                piercingButton, coloringButton, massageButton);
        mainContainer.getChildren().add(filterBox);

        displayServices(null);
    }

    private ToggleButton createFilterButton(String text, ToggleGroup group, String color) {
        ToggleButton button = new ToggleButton(text);
        button.setToggleGroup(group);
        button.setStyle(
                "-fx-background-color: white; " +
                        "-fx-text-fill: " + color + "; " +
                        "-fx-border-color: " + color + "; " +
                        "-fx-border-width: 1; " +
                        "-fx-background-radius: 15; " +
                        "-fx-border-radius: 15; " +
                        "-fx-padding: 8 16; " +
                        "-fx-font-size: 13px;"
        );

        button.selectedProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal) {
                button.setStyle(
                        "-fx-background-color: " + color + "; " +
                                "-fx-text-fill: white; " +
                                "-fx-border-color: " + color + "; " +
                                "-fx-border-width: 1; " +
                                "-fx-background-radius: 15; " +
                                "-fx-border-radius: 15; " +
                                "-fx-padding: 8 16; " +
                                "-fx-font-size: 13px;"
                );
            } else {
                button.setStyle(
                        "-fx-background-color: white; " +
                                "-fx-text-fill: " + color + "; " +
                                "-fx-border-color: " + color + "; " +
                                "-fx-border-width: 1; " +
                                "-fx-background-radius: 15; " +
                                "-fx-border-radius: 15; " +
                                "-fx-padding: 8 16; " +
                                "-fx-font-size: 13px;"
                );
            }
        });

        return button;
    }

    private void displayServices(String category) {
        if (mainContainer.getChildren().size() > 2) {
            mainContainer.getChildren().remove(2, mainContainer.getChildren().size());
        }

        ScrollPane scrollPane = new ScrollPane();
        scrollPane.setFitToWidth(true);
        scrollPane.setStyle("-fx-background: transparent; -fx-background-color: transparent;");
        scrollPane.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);

        FlowPane servicesPane = new FlowPane();
        servicesPane.setAlignment(Pos.TOP_CENTER);
        servicesPane.setHgap(25);
        servicesPane.setVgap(25);
        servicesPane.setPadding(new Insets(20));

        var services = category == null ?
                catalogService.getServices() :
                catalogService.getServicesByCategory(category);

        if (services.isEmpty()) {
            Label noItemsLabel = new Label("Услуги в этой категории временно отсутствуют");
            noItemsLabel.setStyle("-fx-font-size: 16px; -fx-text-fill: #666; -fx-padding: 50;");
            servicesPane.getChildren().add(noItemsLabel);
        } else {
            for (Service service : services) {
                VBox serviceCard = createServiceCard(service);
                servicesPane.getChildren().add(serviceCard);
            }
        }

        scrollPane.setContent(servicesPane);
        mainContainer.getChildren().add(scrollPane);
    }

    private VBox createServiceCard(Service service) {
        VBox card = new VBox(15);
        card.setAlignment(Pos.CENTER);
        card.setPrefSize(260, 380);
        card.setPadding(new Insets(20));
        card.setStyle(
                "-fx-background-color: white; " +
                        "-fx-border-radius: 12; " +
                        "-fx-background-radius: 12; " +
                        "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.08), 8, 0.5, 0, 2);"
        );

        String imagePath = null;

        if (service.getImagePath() != null && !service.getImagePath().isEmpty() &&
                !service.getImagePath().equals("/images/default.jpg")) {
            imagePath = service.getImagePath();
        }
        else if (serviceImageMap.containsKey(service.getName())) {
            imagePath = serviceImageMap.get(service.getName());
        }
        else {
            for (Map.Entry<String, String> entry : serviceImageMap.entrySet()) {
                if (service.getName().toLowerCase().contains(entry.getKey().toLowerCase())) {
                    imagePath = entry.getValue();
                    break;
                }
            }
        }

        if (imagePath == null) {
            imagePath = "/images/default_service.jpg";
        }

        ImageView imageView = loadImage(imagePath, "/images/default_service.jpg", "/images/default_service.jpg");

        if (imageView != null) {
            imageView.setFitWidth(200);
            imageView.setFitHeight(150);
            imageView.setPreserveRatio(true);
            imageView.setStyle(
                    "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.15), 6, 0.3, 0, 2); " +
                            "-fx-background-radius: 8; " +
                            "-fx-border-radius: 8;"
            );
            card.getChildren().add(imageView);
        }

        // Название
        Label nameLabel = new Label(service.getName());
        nameLabel.setStyle(
                "-fx-font-size: 16px; " +
                        "-fx-font-weight: bold; " +
                        "-fx-text-alignment: center; " +
                        "-fx-text-fill: #333; " +
                        "-fx-wrap-text: true;"
        );
        nameLabel.setMaxWidth(200);
        nameLabel.setMinHeight(40);

        // Цена
        Label priceLabel = new Label(String.format("%.0f руб.", service.getPrice()));
        priceLabel.setStyle("-fx-font-size: 20px; -fx-font-weight: bold; -fx-text-fill: #8B008B;");

        // Категория
        Label categoryLabel = new Label(service.getCategory());
        categoryLabel.setStyle(
                "-fx-font-size: 12px; " +
                        "-fx-text-fill: #666; " +
                        "-fx-background-color: #F0F0F0; " +
                        "-fx-padding: 4 10; " +
                        "-fx-background-radius: 10; " +
                        "-fx-border-radius: 10;"
        );

        // Кнопка - фиолетовая для услуг
        Button addButton = new Button("Добавить в корзину");
        addButton.setStyle(
                "-fx-background-color: #8B008B; " +
                        "-fx-text-fill: white; " +
                        "-fx-font-size: 14px; " +
                        "-fx-padding: 8 20; " +
                        "-fx-background-radius: 20; " +
                        "-fx-border-radius: 20; " +
                        "-fx-font-weight: bold;"
        );

        addButton.setOnAction(e -> {
            cartService.addToCart(service, "Service", service.getName(), service.getPrice(), service.getCategory());
            updateCartCount();

            addButton.setText("✓ Добавлено!");
            addButton.setStyle(
                    "-fx-background-color: #4CAF50; " +
                            "-fx-text-fill: white; " +
                            "-fx-font-size: 14px; " +
                            "-fx-padding: 8 20; " +
                            "-fx-background-radius: 20; " +
                            "-fx-border-radius: 20; " +
                            "-fx-font-weight: bold;"
            );

            new Thread(() -> {
                try {
                    Thread.sleep(1500);
                    Platform.runLater(() -> {
                        addButton.setText("Добавить в корзину");
                        addButton.setStyle(
                                "-fx-background-color: #8B008B; " +
                                        "-fx-text-fill: white; " +
                                        "-fx-font-size: 14px; " +
                                        "-fx-padding: 8 20; " +
                                        "-fx-background-radius: 20; " +
                                        "-fx-border-radius: 20; " +
                                        "-fx-font-weight: bold;"
                        );
                    });
                } catch (InterruptedException ex) {
                    ex.printStackTrace();
                }
            }).start();
        });

        VBox contentBox = new VBox(10, nameLabel, categoryLabel, priceLabel, addButton);
        contentBox.setAlignment(Pos.CENTER);
        card.getChildren().add(contentBox);

        card.setOnMouseEntered(e -> {
            card.setStyle(
                    "-fx-background-color: #F9F9F9; " +
                            "-fx-border-radius: 12; " +
                            "-fx-background-radius: 12; " +
                            "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.12), 12, 0.5, 0, 3); " +
                            "-fx-cursor: hand;"
            );
        });

        card.setOnMouseExited(e -> {
            card.setStyle(
                    "-fx-background-color: white; " +
                            "-fx-border-radius: 12; " +
                            "-fx-background-radius: 12; " +
                            "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.08), 8, 0.5, 0, 2);"
            );
        });

        return card;
    }

    private void showProductsCatalog() {
        mainContainer.getChildren().clear();

        HBox headerBox = new HBox(15);
        headerBox.setAlignment(Pos.CENTER_LEFT);
        headerBox.setPadding(new Insets(20, 20, 30, 20));

        // Кнопка "Назад" для товаров - розовая
        Button backButton = new Button("← Назад");
        backButton.setStyle(
                "-fx-background-color: #FF69B4; " +
                        "-fx-text-fill: white; " +
                        "-fx-font-size: 14px; " +
                        "-fx-padding: 8 20; " +
                        "-fx-background-radius: 20; " +
                        "-fx-border-radius: 20; " +
                        "-fx-font-weight: bold;"
        );
        backButton.setOnAction(e -> showMainMenu());

        Label title = new Label("Товары для ухода");
        title.setStyle("-fx-font-size: 28px; -fx-font-weight: bold; -fx-text-fill: #FF69B4;");

        HBox.setHgrow(title, Priority.ALWAYS);
        title.setAlignment(Pos.CENTER);

        headerBox.getChildren().addAll(backButton, title);
        mainContainer.getChildren().add(headerBox);

        HBox filterBox = new HBox(10);
        filterBox.setAlignment(Pos.CENTER);
        filterBox.setPadding(new Insets(0, 0, 20, 0));

        ToggleGroup categoryGroup = new ToggleGroup();

        ToggleButton allButton = createFilterButton("Все", categoryGroup, "#FF69B4");
        ToggleButton faceButton = createFilterButton("Лицо", categoryGroup, "#FF69B4");
        ToggleButton bodyButton = createFilterButton("Тело", categoryGroup, "#FF69B4");

        allButton.setSelected(true);

        categoryGroup.selectedToggleProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal == allButton) displayProducts(null);
            else if (newVal == faceButton) displayProducts("Уход за лицом");
            else if (newVal == bodyButton) displayProducts("Уход за телом");
        });

        filterBox.getChildren().addAll(allButton, faceButton, bodyButton);
        mainContainer.getChildren().add(filterBox);

        displayProducts(null);
    }

    private void displayProducts(String category) {
        if (mainContainer.getChildren().size() > 2) {
            mainContainer.getChildren().remove(2, mainContainer.getChildren().size());
        }

        ScrollPane scrollPane = new ScrollPane();
        scrollPane.setFitToWidth(true);
        scrollPane.setStyle("-fx-background: transparent; -fx-background-color: transparent;");
        scrollPane.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);

        FlowPane productsPane = new FlowPane();
        productsPane.setAlignment(Pos.TOP_CENTER);
        productsPane.setHgap(25);
        productsPane.setVgap(25);
        productsPane.setPadding(new Insets(20));

        var products = category == null ?
                catalogService.getProducts() :
                catalogService.getProductsByCategory(category);

        if (products.isEmpty()) {
            Label noItemsLabel = new Label("Товары в этой категории временно отсутствуют");
            noItemsLabel.setStyle("-fx-font-size: 16px; -fx-text-fill: #666; -fx-padding: 50;");
            productsPane.getChildren().add(noItemsLabel);
        } else {
            for (Product product : products) {
                VBox productCard = createProductCard(product);
                productsPane.getChildren().add(productCard);
            }
        }

        scrollPane.setContent(productsPane);
        mainContainer.getChildren().add(scrollPane);
    }

    private VBox createProductCard(Product product) {
        VBox card = new VBox(15);
        card.setAlignment(Pos.CENTER);
        card.setPrefSize(260, 380);
        card.setPadding(new Insets(20));
        card.setStyle(
                "-fx-background-color: white; " +
                        "-fx-border-radius: 12; " +
                        "-fx-background-radius: 12; " +
                        "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.08), 8, 0.5, 0, 2);"
        );

        String imagePath = null;

        if (product.getImagePath() != null && !product.getImagePath().isEmpty() &&
                !product.getImagePath().equals("/images/default.jpg")) {
            imagePath = product.getImagePath();
        }
        else if (productImageMap.containsKey(product.getName())) {
            imagePath = productImageMap.get(product.getName());
        }
        else {
            for (Map.Entry<String, String> entry : productImageMap.entrySet()) {
                if (product.getName().toLowerCase().contains(entry.getKey().toLowerCase())) {
                    imagePath = entry.getValue();
                    break;
                }
            }
        }

        if (imagePath == null) {
            imagePath = "/images/default_product.jpg";
        }

        ImageView imageView = loadImage(imagePath, "/images/default_product.jpg", "/images/default_product.jpg");

        if (imageView != null) {
            imageView.setFitWidth(200);
            imageView.setFitHeight(150);
            imageView.setPreserveRatio(true);
            imageView.setStyle(
                    "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.15), 6, 0.3, 0, 2); " +
                            "-fx-background-radius: 8; " +
                            "-fx-border-radius: 8;"
            );
            card.getChildren().add(imageView);
        }

        // Название
        Label nameLabel = new Label(product.getName());
        nameLabel.setStyle(
                "-fx-font-size: 16px; " +
                        "-fx-font-weight: bold; " +
                        "-fx-text-alignment: center; " +
                        "-fx-text-fill: #333; " +
                        "-fx-wrap-text: true;"
        );
        nameLabel.setMaxWidth(200);
        nameLabel.setMinHeight(40);

        // Цена
        Label priceLabel = new Label(String.format("%.0f руб.", product.getPrice()));
        priceLabel.setStyle("-fx-font-size: 20px; -fx-font-weight: bold; -fx-text-fill: #FF69B4;");

        // Категория
        Label categoryLabel = new Label(product.getCategory());
        categoryLabel.setStyle(
                "-fx-font-size: 12px; " +
                        "-fx-text-fill: #666; " +
                        "-fx-background-color: #F0F0F0; " +
                        "-fx-padding: 4 10; " +
                        "-fx-background-radius: 10; " +
                        "-fx-border-radius: 10;"
        );

        // Кнопка - розовая для товаров
        Button addButton = new Button("Добавить в корзину");
        addButton.setStyle(
                "-fx-background-color: #FF69B4; " +
                        "-fx-text-fill: white; " +
                        "-fx-font-size: 14px; " +
                        "-fx-padding: 8 20; " +
                        "-fx-background-radius: 20; " +
                        "-fx-border-radius: 20; " +
                        "-fx-font-weight: bold;"
        );

        addButton.setOnAction(e -> {
            cartService.addToCart(product, "Product", product.getName(), product.getPrice(), product.getCategory());
            updateCartCount();

            addButton.setText("✓ Добавлено!");
            addButton.setStyle(
                    "-fx-background-color: #4CAF50; " +
                            "-fx-text-fill: white; " +
                            "-fx-font-size: 14px; " +
                            "-fx-padding: 8 20; " +
                            "-fx-background-radius: 20; " +
                            "-fx-border-radius: 20; " +
                            "-fx-font-weight: bold;"
            );

            new Thread(() -> {
                try {
                    Thread.sleep(1500);
                    Platform.runLater(() -> {
                        addButton.setText("Добавить в корзину");
                        addButton.setStyle(
                                "-fx-background-color: #FF69B4; " +
                                        "-fx-text-fill: white; " +
                                        "-fx-font-size: 14px; " +
                                        "-fx-padding: 8 20; " +
                                        "-fx-background-radius: 20; " +
                                        "-fx-border-radius: 20; " +
                                        "-fx-font-weight: bold;"
                        );
                    });
                } catch (InterruptedException ex) {
                    ex.printStackTrace();
                }
            }).start();
        });

        VBox contentBox = new VBox(10, nameLabel, categoryLabel, priceLabel, addButton);
        contentBox.setAlignment(Pos.CENTER);
        card.getChildren().add(contentBox);

        card.setOnMouseEntered(e -> {
            card.setStyle(
                    "-fx-background-color: #F9F9F9; " +
                            "-fx-border-radius: 12; " +
                            "-fx-background-radius: 12; " +
                            "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.12), 12, 0.5, 0, 3); " +
                            "-fx-cursor: hand;"
            );
        });

        card.setOnMouseExited(e -> {
            card.setStyle(
                    "-fx-background-color: white; " +
                            "-fx-border-radius: 12; " +
                            "-fx-background-radius: 12; " +
                            "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.08), 8, 0.5, 0, 2);"
            );
        });

        return card;
    }

    private ImageView loadImage(String primaryPath, String fallbackPath, String defaultPath) {
        ImageView imageView = new ImageView();

        String[] pathsToTry = {primaryPath, fallbackPath, defaultPath, "/images/default.jpg"};

        for (String path : pathsToTry) {
            if (path == null || path.isEmpty()) continue;

            try {
                InputStream inputStream = getClass().getResourceAsStream(path);
                if (inputStream != null) {
                    Image image = new Image(inputStream);
                    imageView.setImage(image);
                    return imageView;
                }
            } catch (Exception e) {
                System.err.println("Ошибка загрузки изображения: " + path + " - " + e.getMessage());
            }
        }

        StackPane placeholder = new StackPane();
        placeholder.setPrefSize(200, 150);
        placeholder.setStyle(
                "-fx-background-color: #F0F0F0; " +
                        "-fx-background-radius: 8; " +
                        "-fx-border-radius: 8; " +
                        "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.15), 6, 0.3, 0, 2);"
        );

        Label placeholderLabel = new Label("🛒");
        placeholderLabel.setStyle("-fx-font-size: 40px; -fx-text-fill: #888;");
        placeholder.getChildren().add(placeholderLabel);

        ImageView placeholderImageView = new ImageView();
        placeholderImageView.setFitWidth(200);
        placeholderImageView.setFitHeight(150);
        placeholderImageView.setStyle(
                "-fx-background-color: #F0F0F0; " +
                        "-fx-background-radius: 8; " +
                        "-fx-border-radius: 8; " +
                        "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.15), 6, 0.3, 0, 2);"
        );

        return placeholderImageView;
    }

    @FXML
    private void openCart() {
        CartController.showCart(cartService, this::updateCartCount);
        System.out.println("Открытие корзины");
    }

    @FXML
    private void logout() {
        userService.logout();
        MainApp.showLoginScreen();
    }

    private void updateCartCount() {
        int count = cartService.getItemCount();
        cartCountLabel.setText(String.valueOf(count));

        // Всегда показываем кнопку корзины с фиолетовым фоном
        if (cartButton != null) {
            cartButton.setStyle(
                    "-fx-background-color: #8B008B; " +
                            "-fx-text-fill: white; " +
                            "-fx-font-weight: bold; " +
                            "-fx-background-radius: 20; " +
                            "-fx-border-radius: 20; " +
                            "-fx-padding: 8 20; " +
                            "-fx-font-size: 14px;"
            );
        }
    }
}