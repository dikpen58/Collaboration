package com.example.beautysalon.services;

import com.example.beautysalon.controllers.DatabaseManager;
import com.example.beautysalon.models.User;

public class UserService {
    private static UserService instance;
    private User currentUser;

    private UserService() {}  // приватный конструктор — никто не создаст new UserService()

    public static UserService getInstance() {
        if (instance == null) {
            instance = new UserService();
        }
        return instance;
    }

    public boolean register(String username, String password, boolean isAdmin) {
        // Используем DatabaseManager для регистрации
        boolean success = DatabaseManager.register(username, password, isAdmin);
        if (success) {
            // Автоматически логиним пользователя после регистрации
            currentUser = new User(username, password, isAdmin);
        }
        return success;
    }

    public boolean login(String username, String password) {
        currentUser = DatabaseManager.login(username, password);
        return currentUser != null;
    }

    public void logout() {
        currentUser = null;
    }

    public User getCurrentUser() {
        return currentUser;
    }

    public boolean isLoggedIn() {
        return currentUser != null;
    }
}