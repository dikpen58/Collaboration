package com.example.beautysalon.controllers;

import com.example.beautysalon.MainApp;
import com.example.beautysalon.models.CartItem;
import com.example.beautysalon.models.Order;
import com.example.beautysalon.models.Product;
import com.example.beautysalon.models.Service;
import com.example.beautysalon.services.CatalogService;
import com.example.beautysalon.services.OrderService;
import com.example.beautysalon.services.UserService;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.*;
import java.util.Optional;

public class AdminMainController {

    @FXML private VBox mainContainer;

    private final CatalogService catalogService = new CatalogService();
    private final OrderService orderService = new OrderService();
    private final UserService userService = UserService.getInstance();

    private ObservableList<Service> servicesList;
    private ObservableList<Product> productsList;

    @FXML
    public void initialize() {
        servicesList = FXCollections.observableArrayList(catalogService.getServices());
        productsList = FXCollections.observableArrayList(catalogService.getProducts());

        createAdminInterface();
    }

    private void createAdminInterface() {
        mainContainer.getChildren().clear();

        HBox header = new HBox(20);
        header.setAlignment(Pos.CENTER_LEFT);
        header.setPadding(new Insets(15, 20, 15, 20));
        header.setStyle("-fx-background-color: #f8f9fa; -fx-border-color: #dee2e6; -fx-border-width: 0 0 1 0;");

        Label title = new Label("Панель администратора");
        title.setStyle("-fx-font-size: 24px; -fx-font-weight: bold; -fx-text-fill: #6f42c1;");

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        // Кнопка выхода остается только одна
        Button logoutButton = new Button("Выйти");
        logoutButton.getStyleClass().addAll("btn", "btn-outline-danger");
        logoutButton.setOnAction(e -> logout());

        header.getChildren().addAll(title, spacer, logoutButton);

        TabPane tabPane = new TabPane();
        tabPane.setTabClosingPolicy(TabPane.TabClosingPolicy.UNAVAILABLE);

        Tab servicesTab = new Tab("Услуги");
        Tab productsTab = new Tab("Товары");
        Tab ordersTab = new Tab("Заказы");

        servicesTab.setContent(createServicesTabContent());
        productsTab.setContent(createProductsTabContent());
        ordersTab.setContent(createOrdersTabContent());

        tabPane.getTabs().addAll(servicesTab, productsTab, ordersTab);

        mainContainer.getChildren().addAll(header, tabPane);
        VBox.setVgrow(tabPane, Priority.ALWAYS);
    }

    private VBox createServicesTabContent() {
        TableView<Service> table = new TableView<>(servicesList);
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        TableColumn<Service, String> nameCol = new TableColumn<>("Название");
        nameCol.setCellValueFactory(new PropertyValueFactory<>("name"));

        TableColumn<Service, Number> priceCol = new TableColumn<>("Цена");
        priceCol.setCellValueFactory(new PropertyValueFactory<>("price"));
        priceCol.setStyle("-fx-alignment: CENTER-RIGHT;");

        TableColumn<Service, String> categoryCol = new TableColumn<>("Категория");
        categoryCol.setCellValueFactory(new PropertyValueFactory<>("category"));

        TableColumn<Service, Void> actionsCol = createServiceActionsColumn(table);

        table.getColumns().addAll(nameCol, priceCol, categoryCol, actionsCol);

        Button addButton = new Button("+ Добавить услугу");
        addButton.getStyleClass().add("btn-success");
        addButton.setOnAction(e -> showServiceEditDialog(null, table));

        VBox layout = new VBox(15, addButton, table);
        layout.setPadding(new Insets(20));
        VBox.setVgrow(table, Priority.ALWAYS);

        return layout;
    }

    private TableColumn<Service, Void> createServiceActionsColumn(TableView<Service> table) {
        TableColumn<Service, Void> actionsCol = new TableColumn<>("Действия");

        actionsCol.setCellFactory(param -> new TableCell<>() {
            private final Button editBtn = new Button("Изменить");
            private final Button deleteBtn = new Button("Удалить");

            {
                editBtn.setStyle("-fx-background-color: #ffc107; -fx-text-fill: black; -fx-padding: 5 10;");
                deleteBtn.setStyle("-fx-background-color: #dc3545; -fx-text-fill: white; -fx-padding: 5 10;");

                editBtn.setOnAction(e -> {
                    Service service = getTableView().getItems().get(getIndex());
                    showServiceEditDialog(service, table);
                });

                deleteBtn.setOnAction(e -> {
                    Service service = getTableView().getItems().get(getIndex());
                    deleteService(service, table);
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    HBox box = new HBox(8, editBtn, deleteBtn);
                    box.setAlignment(Pos.CENTER);
                    setGraphic(box);
                }
            }
        });

        return actionsCol;
    }

    private void showServiceEditDialog(Service existing, TableView<Service> table) {
        Dialog<Service> dialog = new Dialog<>();
        dialog.setTitle(existing == null ? "Новая услуга" : "Редактирование услуги");

        GridPane grid = createCommonEditGrid(existing, false);
        dialog.getDialogPane().setContent(grid);
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        dialog.setResultConverter(btn -> {
            if (btn == ButtonType.OK) {
                try {
                    String name = ((TextField) grid.getChildren().get(1)).getText().trim();
                    String priceText = ((TextField) grid.getChildren().get(3)).getText().trim();
                    String category = ((ComboBox<String>) grid.getChildren().get(5)).getValue();
                    String image = ((TextField) grid.getChildren().get(7)).getText().trim();

                    if (name.isEmpty() || priceText.isEmpty() || category == null) {
                        showAlert(Alert.AlertType.ERROR, "Ошибка", "Заполните все обязательные поля");
                        return null;
                    }

                    double price = Double.parseDouble(priceText);

                    Service service = existing != null ? existing : new Service();
                    service.setName(name);
                    service.setPrice(price);
                    service.setCategory(category);
                    service.setImagePath(image.isEmpty() ? "/images/default.jpg" : image);

                    if (existing == null) {
                        catalogService.addService(service);
                        servicesList.add(service);
                    } else {
                        catalogService.updateService(service);
                        table.refresh();
                    }

                    showAlert(Alert.AlertType.INFORMATION, "Успех",
                            existing == null ? "Услуга добавлена" : "Услуга обновлена");
                    return service;
                } catch (NumberFormatException ex) {
                    showAlert(Alert.AlertType.ERROR, "Ошибка", "Некорректный формат цены");
                    return null;
                }
            }
            return null;
        });

        dialog.showAndWait();
    }

    private void deleteService(Service service, TableView<Service> table) {
        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Подтверждение удаления");
        confirm.setHeaderText("Удалить услугу?");
        confirm.setContentText("Вы действительно хотите удалить:\n" + service.getName());

        if (confirm.showAndWait().orElse(ButtonType.CANCEL) == ButtonType.OK) {
            catalogService.deleteService(service.getId());
            servicesList.remove(service);
            table.refresh();
            showAlert(Alert.AlertType.INFORMATION, "Успех", "Услуга удалена");
        }
    }

    private VBox createProductsTabContent() {
        TableView<Product> table = new TableView<>(productsList);
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        TableColumn<Product, String> nameCol = new TableColumn<>("Название");
        nameCol.setCellValueFactory(new PropertyValueFactory<>("name"));

        TableColumn<Product, Number> priceCol = new TableColumn<>("Цена");
        priceCol.setCellValueFactory(new PropertyValueFactory<>("price"));
        priceCol.setStyle("-fx-alignment: CENTER-RIGHT;");

        TableColumn<Product, String> categoryCol = new TableColumn<>("Категория");
        categoryCol.setCellValueFactory(new PropertyValueFactory<>("category"));

        TableColumn<Product, Void> actionsCol = createProductActionsColumn(table);

        table.getColumns().addAll(nameCol, priceCol, categoryCol, actionsCol);

        Button addButton = new Button("+ Добавить товар");
        addButton.getStyleClass().add("btn-success");
        addButton.setOnAction(e -> showProductEditDialog(null, table));

        VBox layout = new VBox(15, addButton, table);
        layout.setPadding(new Insets(20));
        VBox.setVgrow(table, Priority.ALWAYS);

        return layout;
    }

    private TableColumn<Product, Void> createProductActionsColumn(TableView<Product> table) {
        TableColumn<Product, Void> actionsCol = new TableColumn<>("Действия");

        actionsCol.setCellFactory(param -> new TableCell<>() {
            private final Button editBtn = new Button("Изменить");
            private final Button deleteBtn = new Button("Удалить");

            {
                editBtn.setStyle("-fx-background-color: #ffc107; -fx-text-fill: black; -fx-padding: 5 10;");
                deleteBtn.setStyle("-fx-background-color: #dc3545; -fx-text-fill: white; -fx-padding: 5 10;");

                editBtn.setOnAction(e -> {
                    Product product = getTableView().getItems().get(getIndex());
                    showProductEditDialog(product, table);
                });

                deleteBtn.setOnAction(e -> {
                    Product product = getTableView().getItems().get(getIndex());
                    deleteProduct(product, table);
                });
            }

            @Override
            protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    HBox box = new HBox(8, editBtn, deleteBtn);
                    box.setAlignment(Pos.CENTER);
                    setGraphic(box);
                }
            }
        });

        return actionsCol;
    }

    private void showProductEditDialog(Product existing, TableView<Product> table) {
        Dialog<Product> dialog = new Dialog<>();
        dialog.setTitle(existing == null ? "Новый товар" : "Редактирование товара");

        GridPane grid = createCommonEditGrid(existing, true);
        dialog.getDialogPane().setContent(grid);
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

        dialog.setResultConverter(btn -> {
            if (btn == ButtonType.OK) {
                try {
                    String name = ((TextField) grid.getChildren().get(1)).getText().trim();
                    String priceText = ((TextField) grid.getChildren().get(3)).getText().trim();
                    String category = ((ComboBox<String>) grid.getChildren().get(5)).getValue();
                    String image = ((TextField) grid.getChildren().get(7)).getText().trim();

                    if (name.isEmpty() || priceText.isEmpty() || category == null) {
                        showAlert(Alert.AlertType.ERROR, "Ошибка", "Заполните все обязательные поля");
                        return null;
                    }

                    double price = Double.parseDouble(priceText);

                    Product product = existing != null ? existing : new Product();
                    product.setName(name);
                    product.setPrice(price);
                    product.setCategory(category);
                    product.setImagePath(image.isEmpty() ? "/images/default.jpg" : image);

                    if (existing == null) {
                        catalogService.addProduct(product);
                        productsList.add(product);
                    } else {
                        catalogService.updateProduct(product);
                        table.refresh();
                    }

                    showAlert(Alert.AlertType.INFORMATION, "Успех",
                            existing == null ? "Товар добавлен" : "Товар обновлён");
                    return product;
                } catch (NumberFormatException ex) {
                    showAlert(Alert.AlertType.ERROR, "Ошибка", "Некорректный формат цены");
                    return null;
                }
            }
            return null;
        });

        dialog.showAndWait();
    }

    private void deleteProduct(Product product, TableView<Product> table) {
        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION);
        confirm.setTitle("Подтверждение удаления");
        confirm.setHeaderText("Удалить товар?");
        confirm.setContentText("Вы действительно хотите удалить:\n" + product.getName());

        if (confirm.showAndWait().orElse(ButtonType.CANCEL) == ButtonType.OK) {
            catalogService.deleteProduct(product.getId());
            productsList.remove(product);
            table.refresh();
            showAlert(Alert.AlertType.INFORMATION, "Успех", "Товар удалён");
        }
    }

    private GridPane createCommonEditGrid(Object existing, boolean isProduct) {
        GridPane grid = new GridPane();
        grid.setHgap(12);
        grid.setVgap(12);
        grid.setPadding(new Insets(20));

        TextField nameField = new TextField(existing != null ? ((existing instanceof Service s) ? s.getName() : ((Product) existing).getName()) : "");
        TextField priceField = new TextField(existing != null ? String.valueOf(((existing instanceof Service s) ? s.getPrice() : ((Product) existing).getPrice())) : "");
        ComboBox<String> categoryCombo = new ComboBox<>();
        categoryCombo.getItems().addAll(
                "Маникюр", "Педикюр", "Стрижка", "Окрашивание", "Уход за лицом",
                "Массаж", "Проколы", "Наращивание ресниц", "Уход за волосами",
                "Уход за телом", "Другое"
        );
        if (existing != null) {
            String cat = (existing instanceof Service s) ? s.getCategory() : ((Product) existing).getCategory();
            if (cat != null) categoryCombo.setValue(cat);
        }

        TextField imageField = new TextField(existing != null ? ((existing instanceof Service s) ? s.getImagePath() : ((Product) existing).getImagePath()) : "/images/default.jpg");

        grid.add(new Label("Название:"), 0, 0);
        grid.add(nameField, 1, 0);
        grid.add(new Label("Цена:"), 0, 1);
        grid.add(priceField, 1, 1);
        grid.add(new Label("Категория:"), 0, 2);
        grid.add(categoryCombo, 1, 2);
        grid.add(new Label("Изображение:"), 0, 3);
        grid.add(imageField, 1, 3);

        return grid;
    }

    private VBox createOrdersTabContent() {
        TextArea ordersArea = new TextArea();
        ordersArea.setEditable(false);
        ordersArea.setStyle("-fx-font-family: 'Consolas', monospace; -fx-font-size: 14px;");

        refreshOrdersDisplay(ordersArea);

        Button refreshButton = new Button("Обновить список");
        refreshButton.setOnAction(e -> refreshOrdersDisplay(ordersArea));

        VBox layout = new VBox(15, refreshButton, ordersArea);
        layout.setPadding(new Insets(20));
        VBox.setVgrow(ordersArea, Priority.ALWAYS);

        return layout;
    }

    private void refreshOrdersDisplay(TextArea area) {
        StringBuilder sb = new StringBuilder();
        var orders = orderService.getOrders();

        if (orders.isEmpty()) {
            area.setText("Заказов пока нет.");
            return;
        }

        for (Order order : orders) {
            sb.append("═══════════════════════════════════════\n");
            sb.append("Заказ #").append(order.getId()).append("\n");
            sb.append("Клиент: ").append(order.getCustomer()).append("\n");
            sb.append("Адрес: ").append(order.getDeliveryAddress()).append("\n");
            sb.append("Сумма: ").append(String.format("%,.0f ₽", order.getTotalAmount())).append("\n");
            sb.append("Статус: ").append(order.getStatus()).append("\n");
            sb.append("Позиции:\n");

            for (CartItem item : order.getItems()) {
                sb.append(String.format("  • %s × %d = %,.0f ₽\n",
                        item.getName(), item.getQuantity(), item.getTotal()));
            }
            sb.append("\n");
        }

        area.setText(sb.toString());
    }

    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    @FXML
    private void logout() {
        userService.logout();
        MainApp.showLoginScreen();
    }

}