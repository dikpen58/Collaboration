package com.example.beautysalon.controllers;

import com.example.beautysalon.models.CartItem;
import com.example.beautysalon.models.Order;
import com.example.beautysalon.services.CartService;
import com.example.beautysalon.services.OrderService;
import com.example.beautysalon.services.UserService;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class CheckoutController {

    @FXML private TextArea addressField;
    @FXML private Button submitButton;
    @FXML private Button cancelButton;
    @FXML private Label itemsLabel;
    @FXML private Label totalLabel;

    private CartService cartService;
    private Runnable updateCallback;
    private final OrderService orderService = new OrderService();
    private final UserService userService = UserService.getInstance();
    private Stage stage;

    public void setCartService(CartService cartService) {
        this.cartService = cartService;
        updateOrderSummary();
    }

    public void setUpdateCallback(Runnable callback) {
        this.updateCallback = callback;
    }

    public void setStage(Stage stage) {
        this.stage = stage;
    }

    @FXML
    private void initialize() {
    }

    private void updateOrderSummary() {
        if (cartService == null) return;

        StringBuilder itemsText = new StringBuilder("Ваш заказ:\n");
        for (CartItem item : cartService.getCartItems()) {
            itemsText.append(String.format("• %s x%d — %.0f ₽\n",
                    item.getName(), item.getQuantity(), item.getTotal()));
        }
        itemsLabel.setText(itemsText.toString());

        double total = cartService.getTotalAmount();
        totalLabel.setText(String.format("Итого: %.0f ₽", total));
        totalLabel.setStyle("-fx-font-size: 20px; -fx-font-weight: bold; -fx-text-fill: #8B008B;");
    }

    @FXML
    private void handleSubmit() {
        String address = addressField.getText().trim();

        if (address.isEmpty()) {
            showAlert(Alert.AlertType.ERROR, "Ошибка", "Пожалуйста, введите адрес доставки.");
            return;
        }
        if (address.length() < 10) {
            showAlert(Alert.AlertType.WARNING, "Внимание",
                    "Адрес доставки должен содержать не менее 10 символов.");
            return;
        }

        String customer = "Гость";
        if (userService.isLoggedIn() && userService.getCurrentUser() != null) {
            customer = userService.getCurrentUser().getUsername();
            System.out.println("Авторизованный пользователь оформил заказ: " + customer);
        } else {
            System.out.println("Оформлен гостевой заказ");
        }

        Order order = orderService.createOrder(customer, cartService.getCartItems(), address);

        if (order == null) {
            showAlert(Alert.AlertType.ERROR, "Ошибка оформления",
                    "Не удалось создать заказ.\n" +
                            "Проверьте подключение к БД и наличие таблиц.");
            return;
        }

        Alert success = new Alert(Alert.AlertType.INFORMATION);
        success.setTitle("Заказ оформлен!");
        success.setHeaderText("Ваш заказ успешно оформлен");
        success.setContentText(
                "Номер заказа: #" + order.getId() + "\n" +
                        "Клиент: " + customer + "\n" +
                        "Адрес: " + address + "\n\n" +
                        "Сумма: " + String.format("%.0f ₽", order.getTotalAmount()) + "\n" +
                        "Ожидайте доставки в течение 1–2 дней!\n" +
                        "Спасибо за покупку в Studio Mariana!"
        );
        success.showAndWait();

        cartService.clearCart();
        if (stage != null) stage.close();
        if (updateCallback != null) updateCallback.run();
    }

    @FXML
    private void handleCancel() {
        if (stage != null) {
            stage.close();
        }
    }

    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}