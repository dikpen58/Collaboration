package com.example.beautysalon.services;

import com.example.beautysalon.controllers.DatabaseManager;
import com.example.beautysalon.models.Order;
import com.example.beautysalon.models.CartItem;

import java.sql.*;
import java.util.List;

public class OrderService {

    public Order createOrder(String customer, List<CartItem> items, String address) {
        double total = items.stream().mapToDouble(CartItem::getTotal).sum();
        String orderSql = "INSERT INTO orders (customer, total_amount, address, status) VALUES (?, ?, ?, 'В обработке')";

        try (Connection conn = DatabaseManager.getConnection()) {
            conn.setAutoCommit(false);
            try (PreparedStatement psOrder = conn.prepareStatement(orderSql, Statement.RETURN_GENERATED_KEYS)) {
                psOrder.setString(1, customer);
                psOrder.setDouble(2, total);
                psOrder.setString(3, address);
                psOrder.executeUpdate();

                ResultSet rs = psOrder.getGeneratedKeys();
                if (rs.next()) {
                    int orderId = rs.getInt(1);

                    String itemSql = "INSERT INTO order_items (order_id, item_name, price, quantity) VALUES (?, ?, ?, ?)";
                    try (PreparedStatement psItem = conn.prepareStatement(itemSql)) {
                        for (CartItem item : items) {
                            psItem.setInt(1, orderId);
                            psItem.setString(2, item.getName());
                            psItem.setDouble(3, item.getPrice());
                            psItem.setInt(4, item.getQuantity());
                            psItem.addBatch();
                        }
                        psItem.executeBatch();
                    }
                    conn.commit();
                    return new Order(orderId, customer, items, total, address);
                }
            } catch (SQLException e) {
                conn.rollback();
                e.printStackTrace();
                System.err.println("Ошибка создания заказа: " + e.getMessage());
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<Order> getOrders() {
        return DatabaseManager.getAllOrders();
    }

}