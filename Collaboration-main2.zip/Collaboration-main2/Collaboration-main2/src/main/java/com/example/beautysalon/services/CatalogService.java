package com.example.beautysalon.services;

import com.example.beautysalon.controllers.DatabaseManager;
import com.example.beautysalon.models.Product;
import com.example.beautysalon.models.Service;
import java.util.ArrayList;
import java.util.List;

public class CatalogService {
    private List<Service> services;
    private List<Product> products;

    public CatalogService() {
        services = new ArrayList<>(DatabaseManager.getAllServices());
        products = new ArrayList<>(DatabaseManager.getAllProducts());
    }

    public List<Service> getServices() {
        return new ArrayList<>(services);
    }

    public List<Service> getServicesByCategory(String category) {
        List<Service> filtered = new ArrayList<>();
        for (Service service : services) {
            if (service.getCategory().equals(category)) {
                filtered.add(service);
            }
        }
        return filtered;
    }

    public List<Product> getProducts() {
        return new ArrayList<>(products);
    }

    public List<Product> getProductsByCategory(String category) {
        List<Product> filtered = new ArrayList<>();
        for (Product product : products) {
            if (product.getCategory().equals(category)) {
                filtered.add(product);
            }
        }
        return filtered;
    }

    public void addService(Service service) {
        int id = DatabaseManager.addService(service);
        if (id != -1) {
            service.setId(id);
            services.add(service);
        }
    }

    public void updateService(Service updatedService) {
        DatabaseManager.updateService(updatedService);
        for (int i = 0; i < services.size(); i++) {
            if (services.get(i).getId() == updatedService.getId()) {
                services.set(i, updatedService);
                break;
            }
        }
    }

    public void deleteService(int id) {
        DatabaseManager.deleteService(id);
        services.removeIf(s -> s.getId() == id);
    }

    public void addProduct(Product product) {
        int id = DatabaseManager.addProduct(product);
        if (id != -1) {
            product.setId(id);
            products.add(product);
        }
    }

    public void updateProduct(Product updatedProduct) {
        DatabaseManager.updateProduct(updatedProduct);
        for (int i = 0; i < products.size(); i++) {
            if (products.get(i).getId() == updatedProduct.getId()) {
                products.set(i, updatedProduct);
                break;
            }
        }
    }

    public void deleteProduct(int id) {
        DatabaseManager.deleteProduct(id);
        products.removeIf(p -> p.getId() == id);
    }
}